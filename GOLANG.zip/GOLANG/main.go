package main

import (
	"bytes"
	_ "bytes"
	"context"
	"encoding/json"
	_ "encoding/json"
	"fmt"
	_ "fmt"
	_ "github.com/boltdb/bolt"
	"github.com/dgrijalva/jwt-go"
	_ "github.com/dgrijalva/jwt-go"
	_ "github.com/gorilla/mux"
	"github.com/joho/godotenv"
	_ "github.com/joho/godotenv"
	"github.com/thedevsaddam/renderer"
	_ "github.com/thedevsaddam/renderer"
	"go.mongodb.org/mongo-driver/bson"
	_ "go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	_ "go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	_ "go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/mongo/readpref"
	_ "go.mongodb.org/mongo-driver/mongo/readpref"
	"golang.org/x/crypto/bcrypt"
	_ "golang.org/x/crypto/bcrypt"
	_ "io/ioutil"
	"log"
	_ "log"
	"net/http"
	_ "net/http"
	_ "net/url"
	"os"
	_ "os"
	_ "strconv"
	"time"
	_ "time"
)

// define a renderer object
var rnd *renderer.Render

var SecretKey = []byte("gosecretkey")

// User define a struct for the user
type User struct {
	Email    string `json:"email" bson:"email"`
	Password string `json:"password" bson:"password"`
}

var client *mongo.Client

func getHash(pwd []byte) string {
	hash, err := bcrypt.GenerateFromPassword(pwd, bcrypt.MinCost)
	if err != nil {
		log.Println(err)
	}
	return string(hash)
}

func GenerateJWT() (string, error) {
	token := jwt.New(jwt.SigningMethodHS256)
	tokenString, err := token.SignedString(SecretKey)
	if err != nil {
		log.Println("Error in JWT token generation")
		return "", err
	}
	return tokenString, nil
}

func userSignup(response http.ResponseWriter, request *http.Request) {
	response.Header().Set("Content-Type", "application/json")
	var user User
	json.NewDecoder(request.Body).Decode(&user)
	user.Password = getHash([]byte(user.Password))
	collection := client.Database("raven").Collection("user")
	ctx, _ := context.WithTimeout(context.Background(), 10*time.Second)
	result, _ := collection.InsertOne(ctx, user)
	err := json.NewEncoder(response).Encode(result)
	if err != nil {
		return
	}
}

func userLogin(response http.ResponseWriter, request *http.Request) {
	response.Header().Set("Content-Type", "application/json")
	var user User
	var dbUser User
	err := json.NewDecoder(request.Body).Decode(&user)
	if err != nil {
		return
	}
	collection := client.Database("raven").Collection("user")
	ctx, _ := context.WithTimeout(context.Background(), 10*time.Second)
	err = collection.FindOne(ctx, bson.M{"email": user.Email}).Decode(&dbUser)

	if err != nil {
		response.WriteHeader(http.StatusInternalServerError)
		response.Write([]byte(`{"message":"` + err.Error() + `"}`))
		return
	}
	userPass := []byte(user.Password)
	dbPass := []byte(dbUser.Password)

	passErr := bcrypt.CompareHashAndPassword(dbPass, userPass)

	if passErr != nil {
		log.Println(passErr)
		_, err := response.Write([]byte(`{"response":"Wrong Password!"}`))
		if err != nil {
			return
		}
		return
	}
	jwtToken, err := GenerateJWT()
	if err != nil {
		response.WriteHeader(http.StatusInternalServerError)
		_, err := response.Write([]byte(`{"message":"` + err.Error() + `"}`))
		if err != nil {
			return
		}
		return
	}
	_, err = response.Write([]byte(`{"token":"` + jwtToken + `"}`))
	if err != nil {
		return
	}

}

//initialize what is needed for the renderer:
//which template engine to use,
//where to look for templates,
//and what to call the templates
func init() {
	opts := renderer.Options{
		ParseGlobPattern: "./tpl/*.html",
	}
	rnd = renderer.New(opts)
}

// This is a user defined method to close resources.
// This method closes mongoDB connection and cancel context.
func disconnect(client *mongo.Client, ctx context.Context,
	cancel context.CancelFunc) {

	// CancelFunc to cancel to context
	defer cancel()

	// client provides a method to close
	// a mongoDB connection.
	defer func() {

		// client.Disconnect method also has deadline.
		// returns error if any,
		if err := client.Disconnect(ctx); err != nil {
			panic(err)
		}
	}()
}

// This is a user defined method that returns mongo.Client,
// context.Context, context.CancelFunc and error.
// mongo.Client will be used for further database operation.
// context.Context will be used set deadlines for process.
// context.CancelFunc will be used to cancel context and
// resource associated with it.

func connect(uri string) (*mongo.Client, context.Context,
	context.CancelFunc, error) {

	// ctx will be used to set deadline for process, here
	// deadline will of 30 seconds.
	ctx, cancel := context.WithTimeout(context.Background(),
		30*time.Second)

	// mongo.Connect return mongo.Client method
	client, err := mongo.Connect(ctx, options.Client().ApplyURI(uri))
	return client, ctx, cancel, err
}

// This is a user defined method that accepts
// mongo.Client and context.Context
// This method used to ping the mongoDB, return error if any.
func ping(client *mongo.Client, ctx context.Context) error {

	// mongo.Client has Ping to ping mongoDB, deadline of
	// the Ping method will be determined by cxt
	// Ping method return error if any occurred, then
	// the error can be handled.
	if err := client.Ping(ctx, readpref.Primary()); err != nil {
		return err
	}
	fmt.Println("connected successfully")
	return nil
}

func main() {
	// Get Client, Context, CancelFunc and
	// err from connect method.
	uri := os.Getenv("MONGO_URL")
	if uri == "" {
		uri = "mongodb://localhost:27017"
	}
	client, ctx, cancel, err := connect(uri)
	if err != nil {
		panic(err)
	}

	// Release resource when the main
	// function is returned.
	defer disconnect(client, ctx, cancel)

	// Ping mongoDB with Ping method
	err = ping(client, ctx)
	if err != nil {
		return
	}

	err = godotenv.Load()
	if err != nil {
		log.Println("Error loading .env file")
	}

	port := os.Getenv("PORT")
	if port == "" {
		port = "3000"
	}

	fs := http.FileServer(http.Dir("assets"))
	mux := http.NewServeMux()
	mux.Handle("/assets/", http.StripPrefix("/assets/", fs))
	mux.HandleFunc("/", indexHandler)
	mux.HandleFunc("/about", aboutHandler)
	err = http.ListenAndServe(":"+port, mux)
	if err != nil {
		return
	}
	if err != nil {
		return
	}
}

//var tpl = template.Must(template.ParseFiles("tpl/index.html"))

func indexHandler(w http.ResponseWriter, _ *http.Request) {
	buf := &bytes.Buffer{}
	//err := tpl.Execute(w, nil) // static tpl site
	err := rnd.HTML(w, http.StatusOK, "index", nil) // dynamic tpl site
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	_, err = buf.WriteTo(w)
	if err != nil {
		return
	}
}

func aboutHandler(w http.ResponseWriter, _ *http.Request) {
	buf := &bytes.Buffer{}
	//err := tpl.Execute(w, nil) // static tpl site
	err := rnd.HTML(w, http.StatusOK, "about", nil) // dynamic tpl site
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	_, err = buf.WriteTo(w)
	if err != nil {
		return
	}
}
